﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BasicCalc
{
    public partial class BasicCalc : Form
    {
        Double resultValue = 0;
        String operationPerformed = "";
        bool isOperationPerformed = false;
        public BasicCalc()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnClick(object sender, EventArgs e)
        {
            if (txtboxCalc.Text == "0")
            {
                txtboxCalc.Clear();
            }
            isOperationPerformed = false;
            Button button = (Button)sender;
            txtboxCalc.Text = txtboxCalc.Text + button.Text;
        }

        private void oprClick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            operationPerformed = button.Text;
            resultValue = Double.Parse(txtboxCalc.Text);
            isOperationPerformed = true;
            txtboxCalc.Text = "0";
        }

        private void btnCE_Click(object sender, EventArgs e)
        {
            txtboxCalc.Text = "0";
        }

        private void btnC_Click(object sender, EventArgs e)
        {
            txtboxCalc.Text = "0";
            resultValue = 0;
        }

        private void btnEquals_Click(object sender, EventArgs e)
        {
            switch (operationPerformed)
            {
                case "+":
                    txtboxCalc.Text = (resultValue + Double.Parse(txtboxCalc.Text)).ToString();
                    break;
                case "-":
                    txtboxCalc.Text = (resultValue - Double.Parse(txtboxCalc.Text)).ToString();
                    break;
                case "*":
                    txtboxCalc.Text = (resultValue * Double.Parse(txtboxCalc.Text)).ToString();
                    break;
                case "/":
                    txtboxCalc.Text = (resultValue / Double.Parse(txtboxCalc.Text)).ToString();
                    break;
                default:
                    break;
            }
        }
    }
}
